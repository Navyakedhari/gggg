# server_gui.py
# Run this on machine A. It listens for one connection, then you can chat.
# Usage: python server_gui.py
import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox

HOST = '0.0.0.0'   # listen on all interfaces
PORT = 5000        # change if needed

class ChatServer:
    def __init__(self, root):
        self.root = root
        root.title("Chat Server (Two Chat Boxes)")
        self.sock = None
        self.conn = None
        self.addr = None
        self.running = False

        # GUI layout
        top = tk.Frame(root)
        top.pack(padx=8, pady=6, fill='x')

        tk.Label(top, text="Server host:").grid(row=0, column=0, sticky='w')
        self.host_label = tk.Label(top, text=HOST)
        self.host_label.grid(row=0, column=1, sticky='w', padx=(2,10))
        tk.Label(top, text="Port:").grid(row=0, column=2, sticky='w')
        self.port_label = tk.Label(top, text=str(PORT))
        self.port_label.grid(row=0, column=3, sticky='w', padx=(2,10))

        btn_frame = tk.Frame(top)
        btn_frame.grid(row=0, column=4, sticky='e')
        self.start_btn = tk.Button(btn_frame, text="Start Server", command=self.start_server)
        self.start_btn.pack(side='left', padx=2)
        self.stop_btn = tk.Button(btn_frame, text="Stop", command=self.stop_server, state='disabled')
        self.stop_btn.pack(side='left', padx=2)

        # Chat boxes: Received (left) and Sent (right)
        boxes = tk.Frame(root)
        boxes.pack(padx=8, pady=(0,6), fill='both', expand=True)

        left = tk.Frame(boxes)
        left.pack(side='left', fill='both', expand=True, padx=(0,4))
        tk.Label(left, text="Received").pack(anchor='w')
        self.recv_box = scrolledtext.ScrolledText(left, state='disabled', wrap='word', height=12)
        self.recv_box.pack(fill='both', expand=True)

        right = tk.Frame(boxes)
        right.pack(side='left', fill='both', expand=True, padx=(4,0))
        tk.Label(right, text="Sent").pack(anchor='w')
        self.sent_box = scrolledtext.ScrolledText(right, state='disabled', wrap='word', height=12)
        self.sent_box.pack(fill='both', expand=True)

        # input area
        bottom = tk.Frame(root)
        bottom.pack(fill='x', padx=8, pady=(0,8))
        self.entry = tk.Entry(bottom)
        self.entry.pack(side='left', fill='x', expand=True, padx=(0,6))
        self.entry.bind("<Return>", self.on_send)
        self.send_btn = tk.Button(bottom, text="Send", command=self.on_send, state='disabled')
        self.send_btn.pack(side='left')

    def start_server(self):
        if self.running:
            return
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((HOST, PORT))
        self.sock.listen(1)
        self.running = True
        self.start_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        threading.Thread(target=self.accept_loop, daemon=True).start()
        self.append_received(f"Server started, listening on {HOST}:{PORT}\n")

    def accept_loop(self):
        try:
            self.conn, self.addr = self.sock.accept()
            self.append_received(f"Connected by {self.addr}\n")
            self.root.after(0, lambda: self.send_btn.config(state='normal'))
            threading.Thread(target=self.recv_loop, daemon=True).start()
        except Exception as e:
            self.append_received(f"Accept error: {e}\n")

    def recv_loop(self):
        try:
            while True:
                data = self.conn.recv(4096)
                if not data:
                    self.append_received("Connection closed by client.\n")
                    break
                msg = data.decode('utf-8', errors='replace')
                # update GUI from main thread
                self.root.after(0, lambda m=msg: self.append_received(f"Client: {m}\n"))
        except Exception as e:
            self.root.after(0, lambda: self.append_received(f"Receive error: {e}\n"))
        finally:
            self.root.after(0, lambda: self.send_btn.config(state='disabled'))
            self.stop_server()

    def on_send(self, event=None):
        text = self.entry.get().strip()
        if not text or not self.conn:
            return
        try:
            self.conn.sendall(text.encode('utf-8'))
            self.append_sent(f"You: {text}\n")
            self.entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Send error", str(e))
            self.stop_server()

    def append_received(self, text):
        self.recv_box.config(state='normal')
        self.recv_box.insert(tk.END, text)
        self.recv_box.see(tk.END)
        self.recv_box.config(state='disabled')

    def append_sent(self, text):
        self.sent_box.config(state='normal')
        self.sent_box.insert(tk.END, text)
        self.sent_box.see(tk.END)
        self.sent_box.config(state='disabled')

    def stop_server(self):
        if not self.running:
            return
        self.running = False
        try:
            if self.conn:
                self.conn.close()
                self.conn = None
            if self.sock:
                self.sock.close()
                self.sock = None
        except:
            pass
        self.start_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        self.send_btn.config(state='disabled')
        self.append_received("Server stopped.\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatServer(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.stop_server(), root.destroy()))
    root.mainloop()
