# client_gui.py
# Run this on machine B. Change SERVER_HOST to the server IP (machine A).
# Usage: python client_gui.py
import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog, messagebox

SERVER_HOST = '127.0.0.1'  # change to server's IP if running on different machine
SERVER_PORT = 5000

class ChatClient:
    def __init__(self, root):
        self.root = root
        root.title("Chat Client (Two Chat Boxes)")
        self.sock = None
        self.connected = False

        top = tk.Frame(root)
        top.pack(padx=8, pady=6, fill='x')

        tk.Label(top, text="Server:").grid(row=0, column=0, sticky='w')
        self.server_label = tk.Label(top, text=f"{SERVER_HOST}:{SERVER_PORT}")
        self.server_label.grid(row=0, column=1, sticky='w', padx=(2,10))

        btn_frame = tk.Frame(top)
        btn_frame.grid(row=0, column=2, sticky='e')
        self.connect_btn = tk.Button(btn_frame, text="Connect", command=self.connect_to_server)
        self.connect_btn.pack(side='left', padx=2)
        self.disconnect_btn = tk.Button(btn_frame, text="Disconnect", command=self.disconnect, state='disabled')
        self.disconnect_btn.pack(side='left', padx=2)

        boxes = tk.Frame(root)
        boxes.pack(padx=8, pady=(0,6), fill='both', expand=True)

        left = tk.Frame(boxes)
        left.pack(side='left', fill='both', expand=True, padx=(0,4))
        tk.Label(left, text="Received").pack(anchor='w')
        self.recv_box = scrolledtext.ScrolledText(left, state='disabled', wrap='word', height=12)
        self.recv_box.pack(fill='both', expand=True)

        right = tk.Frame(boxes)
        right.pack(side='left', fill='both', expand=True, padx=(4,0))
        tk.Label(right, text="Sent").pack(anchor='w')
        self.sent_box = scrolledtext.ScrolledText(right, state='disabled', wrap='word', height=12)
        self.sent_box.pack(fill='both', expand=True)

        bottom = tk.Frame(root)
        bottom.pack(fill='x', padx=8, pady=(0,8))
        self.entry = tk.Entry(bottom)
        self.entry.pack(side='left', fill='x', expand=True, padx=(0,6))
        self.entry.bind("<Return>", self.on_send)
        self.send_btn = tk.Button(bottom, text="Send", command=self.on_send, state='disabled')
        self.send_btn.pack(side='left')

    def connect_to_server(self):
        # prompt for server IP/port optionally
        ip = simpledialog.askstring("Server IP", "Enter server IP (or leave blank to use default):", initialvalue=SERVER_HOST)
        if ip:
            host = ip
        else:
            host = SERVER_HOST
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((host, SERVER_PORT))
            self.connected = True
            self.connect_btn.config(state='disabled')
            self.disconnect_btn.config(state='normal')
            self.send_btn.config(state='normal')
            self.append_received(f"Connected to {host}:{SERVER_PORT}\n")
            threading.Thread(target=self.recv_loop, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Connection error", str(e))
            if self.sock:
                self.sock.close()
                self.sock = None

    def recv_loop(self):
        try:
            while True:
                data = self.sock.recv(4096)
                if not data:
                    self.root.after(0, lambda: self.append_received("Server closed connection.\n"))
                    break
                msg = data.decode('utf-8', errors='replace')
                self.root.after(0, lambda m=msg: self.append_received(f"Server: {m}\n"))
        except Exception as e:
            self.root.after(0, lambda: self.append_received(f"Receive error: {e}\n"))
        finally:
            self.root.after(0, self.disconnect)

    def on_send(self, event=None):
        text = self.entry.get().strip()
        if not text or not self.connected:
            return
        try:
            self.sock.sendall(text.encode('utf-8'))
            self.append_sent(f"You: {text}\n")
            self.entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Send error", str(e))
            self.disconnect()

    def append_received(self, text):
        self.recv_box.config(state='normal')
        self.recv_box.insert(tk.END, text)
        self.recv_box.see(tk.END)
        self.recv_box.config(state='disabled')

    def append_sent(self, text):
        self.sent_box.config(state='normal')
        self.sent_box.insert(tk.END, text)
        self.sent_box.see(tk.END)
        self.sent_box.config(state='disabled')

    def disconnect(self):
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
        self.sock = None
        self.connected = False
        self.connect_btn.config(state='normal')
        self.disconnect_btn.config(state='disabled')
        self.send_btn.config(state='disabled')
        self.append_received("Disconnected.\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatClient(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.disconnect(), root.destroy()))
    root.mainloop()
