# combined_chat.py
# Combined Server and Client Chat Application
# Shows server and client chat boxes side by side
import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox

HOST = '0.0.0.0'
PORT = 5000

class CombinedChat:
    def __init__(self, root):
        self.root = root
        root.title("Combined Chat - Server & Client")
        root.geometry("1200x700")
        
        # Server variables
        self.server_sock = None
        self.server_conn = None
        self.server_running = False
        
        # Client variables
        self.client_sock = None
        self.client_connected = False
        
        # Top control panel
        top = tk.Frame(root)
        top.pack(padx=8, pady=6, fill='x')
        
        # Server controls
        server_frame = tk.LabelFrame(top, text="Server", padx=5, pady=5)
        server_frame.pack(side='left', padx=5, fill='x', expand=True)
        
        tk.Label(server_frame, text=f"Host: {HOST} | Port: {PORT}").pack(side='left', padx=5)
        self.server_start_btn = tk.Button(server_frame, text="Start Server", command=self.start_server)
        self.server_start_btn.pack(side='left', padx=5)
        self.server_stop_btn = tk.Button(server_frame, text="Stop Server", command=self.stop_server, state='disabled')
        self.server_stop_btn.pack(side='left', padx=5)
        
        # Client controls
        client_frame = tk.LabelFrame(top, text="Client", padx=5, pady=5)
        client_frame.pack(side='left', padx=5, fill='x', expand=True)
        
        tk.Label(client_frame, text="Server IP:").pack(side='left', padx=5)
        self.client_ip_entry = tk.Entry(client_frame, width=15)
        self.client_ip_entry.insert(0, "127.0.0.1")
        self.client_ip_entry.pack(side='left', padx=5)
        tk.Label(client_frame, text=f"Port: {PORT}").pack(side='left', padx=5)
        self.client_connect_btn = tk.Button(client_frame, text="Connect", command=self.connect_client)
        self.client_connect_btn.pack(side='left', padx=5)
        self.client_disconnect_btn = tk.Button(client_frame, text="Disconnect", command=self.disconnect_client, state='disabled')
        self.client_disconnect_btn.pack(side='left', padx=5)
        
        # Main content area - Server and Client side by side
        main_frame = tk.Frame(root)
        main_frame.pack(padx=8, pady=(0,6), fill='both', expand=True)
        
        # Server side (left)
        server_side = tk.Frame(main_frame)
        server_side.pack(side='left', fill='both', expand=True, padx=(0,4))
        
        server_label = tk.Label(server_side, text="SERVER - Received Messages", font=('Arial', 10, 'bold'))
        server_label.pack(anchor='w', pady=(0,5))
        self.server_recv_box = scrolledtext.ScrolledText(server_side, state='disabled', wrap='word', height=12)
        self.server_recv_box.pack(fill='both', expand=True)
        
        server_input_frame = tk.Frame(server_side)
        server_input_frame.pack(fill='x', pady=(5,0))
        self.server_entry = tk.Entry(server_input_frame)
        self.server_entry.pack(side='left', fill='x', expand=True, padx=(0,6))
        self.server_entry.bind("<Return>", lambda e: self.server_send())
        self.server_send_btn = tk.Button(server_input_frame, text="Send", command=self.server_send, state='disabled')
        self.server_send_btn.pack(side='left')
        
        # Client side (right)
        client_side = tk.Frame(main_frame)
        client_side.pack(side='left', fill='both', expand=True, padx=(4,0))
        
        client_label = tk.Label(client_side, text="CLIENT - Received Messages", font=('Arial', 10, 'bold'))
        client_label.pack(anchor='w', pady=(0,5))
        self.client_recv_box = scrolledtext.ScrolledText(client_side, state='disabled', wrap='word', height=12)
        self.client_recv_box.pack(fill='both', expand=True)
        
        client_input_frame = tk.Frame(client_side)
        client_input_frame.pack(fill='x', pady=(5,0))
        self.client_entry = tk.Entry(client_input_frame)
        self.client_entry.pack(side='left', fill='x', expand=True, padx=(0,6))
        self.client_entry.bind("<Return>", lambda e: self.client_send())
        self.client_send_btn = tk.Button(client_input_frame, text="Send", command=self.client_send, state='disabled')
        self.client_send_btn.pack(side='left')
    
    def start_server(self):
        if self.server_running:
            return
        try:
            self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_sock.bind((HOST, PORT))
            self.server_sock.listen(1)
            self.server_running = True
            self.server_start_btn.config(state='disabled')
            self.server_stop_btn.config(state='normal')
            self.server_append(f"Server started, listening on {HOST}:{PORT}\n")
            threading.Thread(target=self.server_accept_loop, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Server Error", f"Failed to start server: {e}")
            self.server_running = False
    
    def server_accept_loop(self):
        try:
            self.server_conn, addr = self.server_sock.accept()
            self.root.after(0, lambda: self.server_append(f"Connected by {addr}\n"))
            self.root.after(0, lambda: self.server_send_btn.config(state='normal'))
            threading.Thread(target=self.server_recv_loop, daemon=True).start()
        except Exception as e:
            if self.server_running:
                self.root.after(0, lambda: self.server_append(f"Accept error: {e}\n"))
    
    def server_recv_loop(self):
        try:
            while self.server_running and self.server_conn:
                data = self.server_conn.recv(4096)
                if not data:
                    self.root.after(0, lambda: self.server_append("Connection closed by client.\n"))
                    break
                msg = data.decode('utf-8', errors='replace')
                self.root.after(0, lambda m=msg: self.server_append(f"Client: {m}\n"))
        except Exception as e:
            if self.server_running:
                self.root.after(0, lambda: self.server_append(f"Receive error: {e}\n"))
        finally:
            if self.server_conn:
                try:
                    self.server_conn.close()
                except:
                    pass
                self.server_conn = None
            self.root.after(0, lambda: self.server_send_btn.config(state='disabled'))
    
    def server_send(self):
        text = self.server_entry.get().strip()
        if not text or not self.server_conn:
            return
        try:
            self.server_conn.sendall(text.encode('utf-8'))
            self.server_append(f"Server: {text}\n")
            self.server_entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Send Error", f"Failed to send: {e}")
            self.stop_server()
    
    def server_append(self, text):
        self.server_recv_box.config(state='normal')
        self.server_recv_box.insert(tk.END, text)
        self.server_recv_box.see(tk.END)
        self.server_recv_box.config(state='disabled')
    
    def stop_server(self):
        if not self.server_running:
            return
        self.server_running = False
        try:
            if self.server_conn:
                self.server_conn.close()
                self.server_conn = None
            if self.server_sock:
                self.server_sock.close()
                self.server_sock = None
        except:
            pass
        self.server_start_btn.config(state='normal')
        self.server_stop_btn.config(state='disabled')
        self.server_send_btn.config(state='disabled')
        self.server_append("Server stopped.\n")
    
    def connect_client(self):
        if self.client_connected:
            return
        host = self.client_ip_entry.get().strip() or "127.0.0.1"
        try:
            self.client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_sock.connect((host, PORT))
            self.client_connected = True
            self.client_connect_btn.config(state='disabled')
            self.client_disconnect_btn.config(state='normal')
            self.client_send_btn.config(state='normal')
            self.client_append(f"Connected to {host}:{PORT}\n")
            threading.Thread(target=self.client_recv_loop, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect: {e}")
            if self.client_sock:
                try:
                    self.client_sock.close()
                except:
                    pass
                self.client_sock = None
    
    def client_recv_loop(self):
        try:
            while self.client_connected and self.client_sock:
                data = self.client_sock.recv(4096)
                if not data:
                    self.root.after(0, lambda: self.client_append("Server closed connection.\n"))
                    break
                msg = data.decode('utf-8', errors='replace')
                self.root.after(0, lambda m=msg: self.client_append(f"Server: {m}\n"))
        except Exception as e:
            if self.client_connected:
                self.root.after(0, lambda: self.client_append(f"Receive error: {e}\n"))
        finally:
            self.root.after(0, self.disconnect_client)
    
    def client_send(self):
        text = self.client_entry.get().strip()
        if not text or not self.client_connected:
            return
        try:
            self.client_sock.sendall(text.encode('utf-8'))
            self.client_append(f"Client: {text}\n")
            self.client_entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Send Error", f"Failed to send: {e}")
            self.disconnect_client()
    
    def client_append(self, text):
        self.client_recv_box.config(state='normal')
        self.client_recv_box.insert(tk.END, text)
        self.client_recv_box.see(tk.END)
        self.client_recv_box.config(state='disabled')
    
    def disconnect_client(self):
        if self.client_sock:
            try:
                self.client_sock.close()
            except:
                pass
        self.client_sock = None
        self.client_connected = False
        self.client_connect_btn.config(state='normal')
        self.client_disconnect_btn.config(state='disabled')
        self.client_send_btn.config(state='disabled')
        self.client_append("Disconnected.\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = CombinedChat(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.stop_server(), app.disconnect_client(), root.destroy()))
    root.mainloop()

